a ='C:\Users\RAHUL\Desktop\Feb7\200imageDataBase';
A =dir( fullfile(a, '*.jpg') );
fileNames = { A.name };
for iFile = 1 : numel( A )
  newName = fullfile(a, sprintf( '%5d.jpg', iFile ) );
  movefile( fullfile(a, fileNames{ iFile }), newName );    
end