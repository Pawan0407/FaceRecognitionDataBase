a ='C:\Users\RAHUL\Desktop\20imagedataBase';
A =dir( fullfile(a, '*.jpg') );
fileNames = { A.name };
for iFile = 1 : numel( A )
  newName = fullfile(a, sprintf( '%5d.jpg', iFile ) );
  movefile( fullfile(a, fileNames{ iFile }), newName );    
end